﻿using Apishki.DTOs.Category;
using Apishki.Models;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers
{
    [ApiController]
    [Route("api/categories")]
    public class CategoriesController : ControllerBase
    {
        private readonly Db33Context _context;

        public CategoriesController(Db33Context context) => _context = context;

        private static CategoryDTO ToDto(Category c) => new CategoryDTO
        {
            Id = c.IdCategory,
            Title = c.Title
        };

        [HttpGet]
        public IActionResult GetAll(int page = 1, int pageSize = 10)
        {
            var items = _context.Categories
                .OrderBy(c => c.IdCategory)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .AsEnumerable()
                .Select(ToDto)
                .ToList();

            return Ok(items);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var c = _context.Categories.FirstOrDefault(x => x.IdCategory == id);
            if (c is null) return NotFound();
            return Ok(ToDto(c));
        }

        [HttpPost]
        public IActionResult Create(CreateCategoryDTO dto)
        {
            var c = new Category { Title = dto.Title };
            _context.Categories.Add(c);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { id = c.IdCategory }, ToDto(c));
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, UpdateCategoryDTO dto)
        {
            var c = _context.Categories.FirstOrDefault(x => x.IdCategory == id);
            if (c is null) return NotFound();

            c.Title = dto.Title;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpPatch("{id}")]
        public IActionResult Patch(int id, PatchCategoryDTO dto)
        {
            var c = _context.Categories.FirstOrDefault(x => x.IdCategory == id);
            if (c is null) return NotFound();

            if (dto.Title is not null) c.Title = dto.Title;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var c = _context.Categories.FirstOrDefault(x => x.IdCategory == id);
            if (c is null) return NotFound();

            _context.Categories.Remove(c);
            _context.SaveChanges();
            return NoContent();
        }
    }
}