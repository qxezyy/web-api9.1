﻿using Apishki.DTOs.Order;
using Apishki.Models;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers
{
    [ApiController]
    [Route("api/orders")]
    public class OrdersController : ControllerBase
    {
        private readonly Db33Context _context;

        public OrdersController(Db33Context context) => _context = context;

        private static OrderDTO ToDto(Order o) => new OrderDTO
        {
            Id = o.IdOrder,
            UuserId = o.UuserId,
            CreatedAt = o.OrderDate,
            Totalamount = o.Totalamount,
            StatusOrder = o.StatusOrder,
            DeliveryAddress = o.DeliveryAddress
        };

        [HttpGet]
        public IActionResult GetAll(int page = 1, int pageSize = 10)
        {
            var items = _context.Orders
                .OrderBy(o => o.IdOrder)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .AsEnumerable()
                .Select(ToDto)
                .ToList();

            return Ok(items);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var o = _context.Orders.FirstOrDefault(x => x.IdOrder == id);
            if (o is null) return NotFound();
            return Ok(ToDto(o));
        }

        [HttpPost]
        public IActionResult Create(CreateOrderDTO dto)
        {
            if (!_context.Users.Any(u => u.IdUser == dto.UuserId))
                return BadRequest($"Пользователь с id={dto.UuserId} не найден");

            var o = new Order
            {
                UuserId = dto.UuserId,
                Totalamount = dto.Totalamount,
                StatusOrder = dto.StatusOrder,
                DeliveryAddress = dto.DeliveryAddress,
                OrderDate = DateTime.UtcNow
            };

            _context.Orders.Add(o);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { id = o.IdOrder }, ToDto(o));
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, UpdateOrderDTO dto)
        {
            var o = _context.Orders.FirstOrDefault(x => x.IdOrder == id);
            if (o is null) return NotFound();

            o.UuserId = dto.UuserId;
            o.Totalamount = dto.Totalamount;
            o.StatusOrder = dto.StatusOrder;
            o.DeliveryAddress = dto.DeliveryAddress;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpPatch("{id}")]
        public IActionResult Patch(int id, PatchOrderDTO dto)
        {
            var o = _context.Orders.FirstOrDefault(x => x.IdOrder == id);
            if (o is null) return NotFound();

            if (dto.UuserId is not null) o.UuserId = dto.UuserId.Value;
            if (dto.Totalamount is not null) o.Totalamount = dto.Totalamount.Value;
            if (dto.StatusOrder is not null) o.StatusOrder = dto.StatusOrder;
            if (dto.DeliveryAddress is not null) o.DeliveryAddress = dto.DeliveryAddress;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var o = _context.Orders.FirstOrDefault(x => x.IdOrder == id);
            if (o is null) return NotFound();

            _context.Orders.Remove(o);
            _context.SaveChanges();
            return NoContent();
        }
    }
}