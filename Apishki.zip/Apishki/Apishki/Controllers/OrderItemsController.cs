﻿using Apishki.DTOs.OrderItem;
using Apishki.Models;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers
{
    [ApiController]
    [Route("api/order-items")]
    public class OrderItemsController : ControllerBase
    {
        private readonly Db33Context _context;

        public OrderItemsController(Db33Context context) => _context = context;

        private static OrderItemDTO ToDto(OrderItem oi) => new OrderItemDTO
        {
            Id = oi.IdOrderitem,
            OrderId = oi.OrderId,
            ProductId = oi.ProductId,
            Title = oi.Title,
            Price = oi.Price,
            Quantity = oi.Quantity
        };

        [HttpGet]
        public IActionResult GetAll(int page = 1, int pageSize = 10)
        {
            var items = _context.OrderItems
                .OrderBy(oi => oi.IdOrderitem)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .AsEnumerable()
                .Select(ToDto)
                .ToList();

            return Ok(items);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var oi = _context.OrderItems.FirstOrDefault(x => x.IdOrderitem == id);
            if (oi is null) return NotFound();
            return Ok(ToDto(oi));
        }

        [HttpPost]
        public IActionResult Create(CreateOrderItemDTO dto)
        {
            if (!_context.Orders.Any(o => o.IdOrder == dto.OrderId))
                return BadRequest($"Заказ с id={dto.OrderId} не найден");
            if (!_context.Products.Any(p => p.IdProduct == dto.ProductId))
                return BadRequest($"Товар с id={dto.ProductId} не найден");

            var oi = new OrderItem
            {
                OrderId = dto.OrderId,
                ProductId = dto.ProductId,
                Title = dto.Title,
                Price = dto.Price,
                Quantity = dto.Quantity
            };

            _context.OrderItems.Add(oi);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { id = oi.IdOrderitem }, ToDto(oi));
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, UpdateOrderItemDTO dto)
        {
            var oi = _context.OrderItems.FirstOrDefault(x => x.IdOrderitem == id);
            if (oi is null) return NotFound();

            oi.OrderId = dto.OrderId;
            oi.ProductId = dto.ProductId;
            oi.Title = dto.Title;
            oi.Price = dto.Price;
            oi.Quantity = dto.Quantity;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpPatch("{id}")]
        public IActionResult Patch(int id, PatchOrderItemDTO dto)
        {
            var oi = _context.OrderItems.FirstOrDefault(x => x.IdOrderitem == id);
            if (oi is null) return NotFound();

            if (dto.OrderId is not null) oi.OrderId = dto.OrderId.Value;
            if (dto.ProductId is not null) oi.ProductId = dto.ProductId.Value;
            if (dto.Title is not null) oi.Title = dto.Title;
            if (dto.Price is not null) oi.Price = dto.Price.Value;
            if (dto.Quantity is not null) oi.Quantity = dto.Quantity.Value;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var oi = _context.OrderItems.FirstOrDefault(x => x.IdOrderitem == id);
            if (oi is null) return NotFound();

            _context.OrderItems.Remove(oi);
            _context.SaveChanges();
            return NoContent();
        }
    }
}