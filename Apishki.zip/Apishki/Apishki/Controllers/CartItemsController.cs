﻿using Apishki.DTOs.CartItem;
using Apishki.Models;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers
{
    [ApiController]
    [Route("api/cart-items")]
    public class CartItemsController : ControllerBase
    {
        private readonly Db33Context _context;

        public CartItemsController(Db33Context context) => _context = context;

        private static CartItemDTO ToDto(CartItem ci) => new CartItemDTO
        {
            Id = ci.IdCartitem,
            CartId = ci.CartId,
            ProductId = ci.ProductId,
            Quantity = ci.Quantity
        };

        [HttpGet]
        public IActionResult GetAll(int page = 1, int pageSize = 10)
        {
            var items = _context.CartItems
                .OrderBy(ci => ci.IdCartitem)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .AsEnumerable()
                .Select(ToDto)
                .ToList();

            return Ok(items);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var ci = _context.CartItems.FirstOrDefault(x => x.IdCartitem == id);
            if (ci is null) return NotFound();
            return Ok(ToDto(ci));
        }

        [HttpPost]
        public IActionResult Create(CreateCartItemDTO dto)
        {
            if (!_context.Carts.Any(c => c.IdCart == dto.CartId))
                return BadRequest($"Корзина с id={dto.CartId} не найдена");
            if (!_context.Products.Any(p => p.IdProduct == dto.ProductId))
                return BadRequest($"Товар с id={dto.ProductId} не найден");

            var ci = new CartItem
            {
                CartId = dto.CartId,
                ProductId = dto.ProductId,
                Quantity = dto.Quantity
            };

            _context.CartItems.Add(ci);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { id = ci.IdCartitem }, ToDto(ci));
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, UpdateCartItemDTO dto)
        {
            var ci = _context.CartItems.FirstOrDefault(x => x.IdCartitem == id);
            if (ci is null) return NotFound();

            ci.CartId = dto.CartId;
            ci.ProductId = dto.ProductId;
            ci.Quantity = dto.Quantity;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpPatch("{id}")]
        public IActionResult Patch(int id, PatchCartItemDTO dto)
        {
            var ci = _context.CartItems.FirstOrDefault(x => x.IdCartitem == id);
            if (ci is null) return NotFound();

            if (dto.CartId is not null) ci.CartId = dto.CartId.Value;
            if (dto.ProductId is not null) ci.ProductId = dto.ProductId.Value;
            if (dto.Quantity is not null) ci.Quantity = dto.Quantity.Value;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var ci = _context.CartItems.FirstOrDefault(x => x.IdCartitem == id);
            if (ci is null) return NotFound();

            _context.CartItems.Remove(ci);
            _context.SaveChanges();
            return NoContent();
        }
    }
}