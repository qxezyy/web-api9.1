﻿using Apishki.DTOs.User;
using Apishki.Models;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers
{
    [ApiController]
    [Route("api/users")]
    public class UsersController : ControllerBase
    {
        private readonly Db33Context _context;

        public UsersController(Db33Context context) => _context = context;

        private static UserDTO ToDto(User u) => new UserDTO
        {
            Id = u.IdUser,
            LoginUser = u.LoginUser,
            PasswordUser = u.PasswordUser,
            RoleId = u.RoleId,
            Email = u.Email,
            CreatedAt = u.RegistrationDate,
            IsActive = u.IsActive
        };

        [HttpGet]
        public IActionResult GetAll(int page = 1, int pageSize = 10)
        {
            var items = _context.Users
                .OrderBy(u => u.IdUser)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .AsEnumerable()
                .Select(ToDto)
                .ToList();

            return Ok(items);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var u = _context.Users.FirstOrDefault(x => x.IdUser == id);
            if (u is null) return NotFound();
            return Ok(ToDto(u));
        }

        [HttpPost]
        public IActionResult Create(CreateUserDTO dto)
        {
            if (!_context.Roles.Any(r => r.IdRole == dto.RoleId))
                return BadRequest($"Роль с id={dto.RoleId} не найдена");

            var u = new User
            {
                LoginUser = dto.LoginUser,
                PasswordUser = dto.PasswordUser,
                RoleId = dto.RoleId,
                Email = dto.Email,
                IsActive = dto.IsActive,
                RegistrationDate = DateTime.UtcNow
            };

            _context.Users.Add(u);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { id = u.IdUser }, ToDto(u));
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, UpdateUserDTO dto)
        {
            var u = _context.Users.FirstOrDefault(x => x.IdUser == id);
            if (u is null) return NotFound();

            u.LoginUser = dto.LoginUser;
            u.PasswordUser = dto.PasswordUser;
            u.RoleId = dto.RoleId;
            u.Email = dto.Email;
            u.IsActive = dto.IsActive;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpPatch("{id}")]
        public IActionResult Patch(int id, PatchUserDTO dto)
        {
            var u = _context.Users.FirstOrDefault(x => x.IdUser == id);
            if (u is null) return NotFound();

            if (dto.LoginUser is not null) u.LoginUser = dto.LoginUser;
            if (dto.PasswordUser is not null) u.PasswordUser = dto.PasswordUser;
            if (dto.RoleId is not null) u.RoleId = dto.RoleId.Value;
            if (dto.Email is not null) u.Email = dto.Email;
            if (dto.IsActive is not null) u.IsActive = dto.IsActive.Value;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var u = _context.Users.FirstOrDefault(x => x.IdUser == id);
            if (u is null) return NotFound();

            _context.Users.Remove(u);
            _context.SaveChanges();
            return NoContent();
        }
    }
}