﻿using Apishki.DTOs.Cart;
using Apishki.Models;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers
{
    [ApiController]
    [Route("api/carts")]
    public class CartsController : ControllerBase
    {
        private readonly Db33Context _context;

        public CartsController(Db33Context context) => _context = context;

        private static CartDTO ToDto(Cart c) => new CartDTO
        {
            Id = c.IdCart,
            UuserId = c.UuserId,
            CreatedAt = c.CreationDate,
            UpdateDate = c.UpdateDate
        };

        [HttpGet]
        public IActionResult GetAll(int page = 1, int pageSize = 10)
        {
            var items = _context.Carts
                .OrderBy(c => c.IdCart)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .AsEnumerable()
                .Select(ToDto)
                .ToList();

            return Ok(items);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var cart = _context.Carts.FirstOrDefault(c => c.IdCart == id);
            if (cart is null) return NotFound();
            return Ok(ToDto(cart));
        }

        [HttpPost]
        public IActionResult Create(CreateCartDTO dto)
        {
            if (!_context.Users.Any(u => u.IdUser == dto.UuserId))
                return BadRequest($"Пользователь с id={dto.UuserId} не найден");

            var cart = new Cart
            {
                UuserId = dto.UuserId,
                CreationDate = DateTime.UtcNow
            };

            _context.Carts.Add(cart);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { id = cart.IdCart }, ToDto(cart));
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, UpdateCartDTO dto)
        {
            var cart = _context.Carts.FirstOrDefault(c => c.IdCart == id);
            if (cart is null) return NotFound();

            cart.UuserId = dto.UuserId;
            cart.UpdateDate = DateTime.UtcNow;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpPatch("{id}")]
        public IActionResult Patch(int id, PatchCartDTO dto)
        {
            var cart = _context.Carts.FirstOrDefault(c => c.IdCart == id);
            if (cart is null) return NotFound();

            if (dto.UuserId is not null) cart.UuserId = dto.UuserId.Value;
            cart.UpdateDate = DateTime.UtcNow;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var cart = _context.Carts.FirstOrDefault(c => c.IdCart == id);
            if (cart is null) return NotFound();

            _context.Carts.Remove(cart);
            _context.SaveChanges();
            return NoContent();
        }
    }
}