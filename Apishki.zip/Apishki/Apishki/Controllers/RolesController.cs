﻿using Apishki.DTOs.Role;
using Apishki.Models;
using Microsoft.AspNetCore.Mvc;

namespace Apishki.Controllers
{
    [ApiController]
    [Route("api/roles")]
    public class RolesController : ControllerBase
    {
        private readonly Db33Context _context;

        public RolesController(Db33Context context) => _context = context;

        private static RoleDTO ToDto(Role r) => new RoleDTO
        {
            Id = r.IdRole,
            Title = r.Title
        };

        [HttpGet]
        public IActionResult GetAll(int page = 1, int pageSize = 10)
        {
            var items = _context.Roles
                .OrderBy(r => r.IdRole)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .AsEnumerable()
                .Select(ToDto)
                .ToList();

            return Ok(items);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var r = _context.Roles.FirstOrDefault(x => x.IdRole == id);
            if (r is null) return NotFound();
            return Ok(ToDto(r));
        }

        [HttpPost]
        public IActionResult Create(CreateRoleDTO dto)
        {
            var r = new Role { Title = dto.Title };
            _context.Roles.Add(r);
            _context.SaveChanges();

            return CreatedAtAction(nameof(GetById), new { id = r.IdRole }, ToDto(r));
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, UpdateRoleDTO dto)
        {
            var r = _context.Roles.FirstOrDefault(x => x.IdRole == id);
            if (r is null) return NotFound();

            r.Title = dto.Title;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpPatch("{id}")]
        public IActionResult Patch(int id, PatchRoleDTO dto)
        {
            var r = _context.Roles.FirstOrDefault(x => x.IdRole == id);
            if (r is null) return NotFound();

            if (dto.Title is not null) r.Title = dto.Title;
            _context.SaveChanges();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var r = _context.Roles.FirstOrDefault(x => x.IdRole == id);
            if (r is null) return NotFound();

            _context.Roles.Remove(r);
            _context.SaveChanges();
            return NoContent();
        }
    }
}