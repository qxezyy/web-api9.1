﻿using System;
using System.Collections.Generic;

namespace Apishki.Models;

public partial class Cart
{
    public int IdCart { get; set; }

    public int UuserId { get; set; }

    public DateTime CreationDate { get; set; }

    public DateTime? UpdateDate { get; set; }

    public virtual ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();

    public virtual User Uuser { get; set; } = null!;
}
