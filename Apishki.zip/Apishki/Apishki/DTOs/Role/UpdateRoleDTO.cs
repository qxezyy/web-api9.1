﻿namespace Apishki.DTOs.Role
{
    public class UpdateRoleDTO
    {
        public string Title { get; set; } = null!;
    }
}