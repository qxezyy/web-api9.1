﻿namespace Apishki.DTOs.Role
{
    public class RoleDTO
    {
        public int Id { get; set; }
        public string Title { get; set; } = null!;
    }
}