﻿namespace Apishki.DTOs.Role
{
    public class PatchRoleDTO
    {
        public string? Title { get; set; }
    }
}