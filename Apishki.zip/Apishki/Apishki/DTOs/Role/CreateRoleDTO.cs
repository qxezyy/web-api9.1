﻿namespace Apishki.DTOs.Role
{
    public class CreateRoleDTO
    {
        public string Title { get; set; } = null!;
    }
}