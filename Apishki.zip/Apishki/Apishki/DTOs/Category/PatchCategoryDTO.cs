﻿namespace Apishki.DTOs.Category
{
    public class PatchCategoryDTO
    {
        public string? Title { get; set; }
    }
}