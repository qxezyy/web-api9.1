﻿namespace Apishki.DTOs.Category
{
    public class CreateCategoryDTO
    {
        public string Title { get; set; } = null!;
    }
}
