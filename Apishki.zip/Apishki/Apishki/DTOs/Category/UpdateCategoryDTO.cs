﻿namespace Apishki.DTOs.Category
{
    public class UpdateCategoryDTO
    {
        public string Title { get; set; } = null!;
    }
}
