﻿namespace Apishki.DTOs.Category
{
    public class CategoryDTO
    {
        public int Id { get; set; }
        public string Title { get; set; } = null!;
    }
}