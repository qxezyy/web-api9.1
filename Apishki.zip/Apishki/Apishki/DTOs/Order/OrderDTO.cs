﻿namespace Apishki.DTOs.Order
{
    public class OrderDTO
    {
        public int Id { get; set; }
        public int UuserId { get; set; }
        public DateTime CreatedAt { get; set; } 
        public decimal Totalamount { get; set; }
        public string StatusOrder { get; set; } = null!;
        public string? DeliveryAddress { get; set; }
    }
}
