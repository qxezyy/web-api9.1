﻿namespace Apishki.DTOs.Order
{
    public class CreateOrderDTO
    {
        public int UuserId { get; set; }
        public decimal Totalamount { get; set; }
        public string StatusOrder { get; set; } = null!;
        public string? DeliveryAddress { get; set; }
    }
}