﻿namespace Apishki.DTOs.Order
{
    public class PatchOrderDTO
    {
        public int? UuserId { get; set; }
        public decimal? Totalamount { get; set; }
        public string? StatusOrder { get; set; }
        public string? DeliveryAddress { get; set; }
    }
}