﻿namespace Apishki.DTOs.User
{
    public class PatchUserDTO
    {
        public string? LoginUser { get; set; }
        public string? PasswordUser { get; set; }
        public int? RoleId { get; set; }
        public string? Email { get; set; }
        public bool? IsActive { get; set; }
    }
}