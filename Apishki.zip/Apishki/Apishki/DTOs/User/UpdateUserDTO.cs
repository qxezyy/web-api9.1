﻿namespace Apishki.DTOs.User
{
    public class UpdateUserDTO
    {
        public string LoginUser { get; set; } = null!;
        public string PasswordUser { get; set; } = null!;
        public int RoleId { get; set; }
        public string? Email { get; set; }
        public bool IsActive { get; set; }
    }
}