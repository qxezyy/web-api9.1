﻿namespace Apishki.DTOs.User
{
    public class UserDTO
    {
        public int Id { get; set; }
        public string LoginUser { get; set; } = null!;
        public string PasswordUser { get; set; } = null!;
        public int RoleId { get; set; }
        public string? Email { get; set; }
        public DateTime CreatedAt { get; set; }  
        public bool IsActive { get; set; }
    }
}