﻿namespace Apishki.DTOs.Cart
{
    public class CreateCartDTO
    {
        public int UuserId { get; set; }
    }
}