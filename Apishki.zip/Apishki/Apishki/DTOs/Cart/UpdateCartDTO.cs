﻿namespace Apishki.DTOs.Cart
{
    public class UpdateCartDTO
    {
        public int UuserId { get; set; }
    }
}