﻿namespace Apishki.DTOs.Cart
{
    public class PatchCartDTO
    {
        public int? UuserId { get; set; }
    }
}