﻿namespace Apishki.DTOs.OrderItem
{
    public class PatchOrderItemDTO
    {
        public int? OrderId { get; set; }
        public int? ProductId { get; set; }
        public string? Title { get; set; }
        public decimal? Price { get; set; }
        public int? Quantity { get; set; }
    }
}